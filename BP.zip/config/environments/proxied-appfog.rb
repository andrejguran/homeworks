Web::Application.configure do
	config.active_support.deprecation = :notify
end