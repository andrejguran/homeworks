package ulohy;

/**
 *
 * @author Zuzana
 */
public class Geometry {

    /**
     * @param args the command line arguments
     */
   public double getAreaOfSquare(double edge){       
       return edge*edge;
    }
   
   public double getAreaOfCircle(double radius){       
       return Math.PI*radius*radius;
   }
   
   public double getPerimeterOfCircle(double radius)
    {
        return (2*Math.PI*radius);
    }
   
  public double getPerimeterOfSquare(double edge)
   {
       return (4*edge + 99999);
   } 
  
  public double getAreaOfRectangle(double edgeA, double edgeB){
       
       return edgeA*edgeB;
    }
  
  public double getPerimeterOfRectangle(double edgeA, double edgeB){
       return (2*edgeA + 2*edgeB);
   } 
          
}
