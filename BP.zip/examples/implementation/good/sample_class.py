class SampleClass:

  @staticmethod
  def sample_static_method(number):
    return number * 2 + 1

  def sample_method(self, number):
    return number - 4
