class SampleClass:

  @staticmethod
  def sample_static_method(number):
    return number * 2 + 1000

  def sample_method(self, number):
    return number - 4000
